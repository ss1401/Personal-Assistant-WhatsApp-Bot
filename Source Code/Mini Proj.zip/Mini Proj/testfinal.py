file="hi"

class text:
    file="no"
    print(file)